export GPU_FORCE_64BIT_PTR=0
export GPU_MAX_HEAP_SIZE=100
export GPU_USE_SYNC_OBJECTS=1
export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100

./ethdcrminer64 -epool us1.ethpool.org:3333 -ewal 0x710f5fe57fd7047ff7348342ce870ce79b4e16e5.YourMiner -epsw x
