./ethdcrminer64 -epool us1.ethpool.org:3333 -ewal 0x710f5fe57fd7047ff7348342ce870ce79b4e16e5.YourMiner -epsw x
